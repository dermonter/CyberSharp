﻿using CyberSharp.Helpers;

namespace CyberSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            IGame game = new Game();
            game.Start();
        }
    }
}
